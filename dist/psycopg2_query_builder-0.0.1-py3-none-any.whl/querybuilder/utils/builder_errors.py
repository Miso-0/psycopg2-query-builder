class QueryErrors(ValueError):
    def __int__(self, *args, **kwargs):
        pass
